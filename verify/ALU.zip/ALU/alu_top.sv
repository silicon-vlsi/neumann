//==============================================================================
// alu_top.sv  (top / harness)
//------------------------------------------------------------------------------
// Static top: makes the clock, the interface, instantiates the DUT, connects
// pins to the interface, then kicks off the class-based test.
//==============================================================================
`timescale 1ns/1ps
`include "rv32i_defines.vh"

module alu_top;
    import alu_pkg::*;

    //--------------------------------------------------------------------------
    // clock
    //--------------------------------------------------------------------------
    logic clk = 0;
    always #5 clk = ~clk;      // 100 MHz

    //--------------------------------------------------------------------------
    // interface (OP_W must match your `ALU_OP_WIDTH)
    //--------------------------------------------------------------------------
    alu_if #(.OP_W(`ALU_OP_WIDTH)) vif (.clk(clk));

    //--------------------------------------------------------------------------
    // DUT — connect pins to interface signals
    //--------------------------------------------------------------------------
    rv32i_alu dut (
        .operator_i          (vif.operator_i),
        .operand_a_i         (vif.operand_a_i),
        .operand_b_i         (vif.operand_b_i),
        .adder_result_o      (vif.adder_result_o),
        .result_o            (vif.result_o),
        .comparison_result_o (vif.comparison_result_o),
        .is_equal_result_o   (vif.is_equal_result_o)
    );

    //--------------------------------------------------------------------------
    // bind SVA assertions into the DUT (no RTL edit needed)
    //--------------------------------------------------------------------------
    bind rv32i_alu alu_assertions #(.OP_W(`ALU_OP_WIDTH)) u_alu_sva (
        .clk   (alu_top.clk),
        .rst_n (1'b1),
        .*                       // connect same-named DUT ports
    );

    //--------------------------------------------------------------------------
    // waves + run test
    //--------------------------------------------------------------------------
    initial begin
        $dumpfile("alu_top.vcd");
        $dumpvars(0, alu_top);

        begin
            test t;
            t = new(vif);   // pass virtual interface into test
            t.run();        // blocks until env finishes + reports
        end

        $finish;
    end

    // safety timeout
    initial begin
        #50000000;
        $display("ERROR: global timeout");
        $finish;
    end

endmodule
