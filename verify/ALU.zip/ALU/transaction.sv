//==============================================================================
// transaction.sv
//------------------------------------------------------------------------------
// The "packet" that flows through the whole TB. One transaction = one ALU op.
// Randomizable inputs + expected outputs (filled by scoreboard reference model).
//==============================================================================
class transaction;

    // ---- stimulus (randomized) ----
    rand bit [5:0]  operator;     // opcode (width must match OP_W)
    rand bit [31:0] operand_a;
    rand bit [31:0] operand_b;

    // ---- captured / expected results ----
    bit [31:0] result;            // DUT result_o (filled by monitor)
    bit        comparison_result; // DUT comparison_result_o
    bit        is_equal_result;   // DUT is_equal_result_o
    bit [31:0] adder_result;      // DUT adder_result_o

    bit [31:0] exp_result;        // golden expected (scoreboard fills)
    bit        exp_cmp;           // golden expected compare

    // ---- constraints ----
    // Bias operand corners so coverage corners get hit often.
    constraint c_operands {
        operand_a dist { 32'h0000_0000 :/ 5, 32'hFFFF_FFFF :/ 5,
                         32'h7FFF_FFFF :/ 5, 32'h8000_0000 :/ 5,
                         [1:32'hFFFF_FFFE] :/ 80 };
        operand_b dist { 32'h0000_0000 :/ 5, 32'hFFFF_FFFF :/ 5,
                         32'h7FFF_FFFF :/ 5, 32'h8000_0000 :/ 5,
                         [1:32'hFFFF_FFFE] :/ 80 };
    }

    // NOTE: opcode is usually forced by the test (loop over all ops), so left
    // unconstrained here — override with inline constraint when randomizing.

    // deep copy (handy for scoreboard/monitor handoff)
    function transaction copy();
        copy = new();
        copy.operator          = operator;
        copy.operand_a         = operand_a;
        copy.operand_b         = operand_b;
        copy.result            = result;
        copy.comparison_result = comparison_result;
        copy.is_equal_result   = is_equal_result;
        copy.adder_result      = adder_result;
        copy.exp_result        = exp_result;
        copy.exp_cmp           = exp_cmp;
    endfunction

    // debug print
    function void print(string tag = "");
        $display("[%s] op=%0h a=%08h b=%08h | res=%08h exp=%08h cmp=%b eq=%b",
                 tag, operator, operand_a, operand_b,
                 result, exp_result, comparison_result, is_equal_result);
    endfunction

endclass
