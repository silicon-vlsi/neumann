//==============================================================================
// environment.sv
//------------------------------------------------------------------------------
// Container that builds + wires + runs all components:
//   generator -> (mbx) -> driver -> DUT -> monitor -> scoreboard
//                                                  \-> coverage
//==============================================================================
class environment;

    // components
    generator     gen;
    driver        drv;
    monitor       mon;
    scoreboard    scb;
    coverage_inf  cov;

    // channels
    mailbox #(transaction) gen2drv;
    mailbox #(transaction) mon2scb;
    mailbox #(transaction) mon2cov;

    event gen_done;                  // generator finished producing
    virtual alu_if vif;

    function new(virtual alu_if vif);
        this.vif = vif;

        // build mailboxes
        gen2drv = new();
        mon2scb = new();
        mon2cov = new();

        // build components
        gen = new(gen2drv, gen_done);
        drv = new(vif, gen2drv);
        mon = new(vif, mon2scb, mon2cov);
        scb = new(mon2scb);
        cov = new(mon2cov);
    endfunction

    // run everything in parallel; finish when generator done + pipes drained
    task run();
        fork
            gen.run();
            drv.run();
            mon.run();
            scb.run();
            cov.run();
        join_none

        // wait for generation to complete
        @(gen_done);
        
        // wait for the driver to finish sending all transactions
        wait(gen2drv.num() == 0);
        
        // wait for the scoreboard to process them
        wait(mon2scb.num() == 0);

        // let pipeline drain
        repeat (10) @(posedge vif.clk);

        // final reports
        scb.report();
        cov.report();
    endtask

endclass
