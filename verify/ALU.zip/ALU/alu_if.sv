//==============================================================================
// alu_if.sv
//------------------------------------------------------------------------------
// Interface = bundle of DUT wires + clocking blocks. Every layered component
// (driver/monitor/coverage) talks to the DUT ONLY through this handle.
// ALU is combinational, but we still add a clock so driver/monitor have a
// timing edge to sync on (pure-comb TB with no clock is racy).
//==============================================================================
`timescale 1ns/1ps
interface alu_if #(parameter OP_W = 6) (input logic clk);

    // DUT pins
    logic [OP_W-1:0] operator_i;          // opcode
    logic [31:0]     operand_a_i;         // A
    logic [31:0]     operand_b_i;         // B
    logic [31:0]     adder_result_o;      // raw adder out
    logic [31:0]     result_o;            // main result
    logic            comparison_result_o; // branch cmp
    logic            is_equal_result_o;   // A-B==0

    // DRIVER clocking block: TB drives inputs on posedge
    clocking drv_cb @(posedge clk);
        default output #1;                // apply 1ns after edge
        output operator_i, operand_a_i, operand_b_i;
    endclocking

    // MONITOR clocking block: TB samples outputs on posedge
    clocking mon_cb @(posedge clk);
        default input #1step;             // sample just before edge
        input operator_i, operand_a_i, operand_b_i;
        input result_o, comparison_result_o, is_equal_result_o, adder_result_o;
    endclocking

    // modports = who-drives-what views
    modport DRV (clocking drv_cb, input clk);
    modport MON (clocking mon_cb, input clk);

endinterface
