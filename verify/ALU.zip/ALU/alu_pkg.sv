//==============================================================================
// alu_pkg.sv
//------------------------------------------------------------------------------
// Package bundling every class so top just does `import alu_pkg::*`.
// Opcode macros come from your defines file — included here so classes see them.
//
// IMPORTANT: adjust the include path / macro names to match your real
// zeroriscy_defines.vh (or replace with localparams if you prefer).
//==============================================================================
package alu_pkg;

    // pull in `ALU_* opcode macros. If your defines are in a .vh, include it
    // BEFORE the classes so covergroup/scoreboard bins resolve.
    `include "rv32i_defines.vh"

    // class files (order matters: base types first)
    `include "transaction.sv"
    `include "generator.sv"
    `include "driver.sv"
    `include "monitor.sv"
    `include "scoreboard.sv"
    `include "coverage_inf.sv"
    `include "environment.sv"
    `include "test.sv"

endpackage
