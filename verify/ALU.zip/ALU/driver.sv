//==============================================================================
// driver.sv
//------------------------------------------------------------------------------
// Pulls transactions from generator, drives them onto the DUT via the
// interface clocking block. One transaction per clock.
//==============================================================================
class driver;

    virtual alu_if vif;                // handle to DUT pins
    mailbox #(transaction) gen2drv;    // from generator
    int drv_count = 0;

    function new(virtual alu_if vif, mailbox #(transaction) gen2drv);
        this.vif     = vif;
        this.gen2drv = gen2drv;
    endfunction

    task run();
        transaction tr;
        forever begin
            gen2drv.get(tr);                       // block until a txn arrives
            @(vif.drv_cb);                         // sync to clock
            vif.drv_cb.operator_i  <= tr.operator; // drive inputs
            vif.drv_cb.operand_a_i <= tr.operand_a;
            vif.drv_cb.operand_b_i <= tr.operand_b;
            drv_count++;
        end
    endtask

endclass
