//==============================================================================
// generator.sv
//------------------------------------------------------------------------------
// Creates transactions and pushes them to the driver over a mailbox.
// Test controls: how many per op, and which opcode list to sweep.
//==============================================================================
class generator;

    mailbox #(transaction) gen2drv;   // gen -> driver channel
    event                  done;      // fired when generation finished

    // opcode list to sweep (test loads this)
    bit [5:0] op_list[$];
    int       num_per_op = 200;       // random txns per opcode

    function new(mailbox #(transaction) gen2drv, event done);
        this.gen2drv = gen2drv;
        this.done    = done;
    endfunction

    // main loop: for each op, generate directed corners + random txns
    task run();
        transaction tr;

        foreach (op_list[i]) begin

            // -- directed corner pass (guarantees corner bins) --
            bit [31:0] corners[] = '{32'h0, 32'h1, 32'hFFFF_FFFF,
                                     32'h7FFF_FFFF, 32'h8000_0000,
                                     32'hA5A5_A5A5, 32'h5A5A_5A5A};
            foreach (corners[ai]) begin
                foreach (corners[bi]) begin
                    tr = new();
                    tr.operator  = op_list[i];
                    tr.operand_a = corners[ai];
                    tr.operand_b = corners[bi];
                    gen2drv.put(tr);
                end
            end

            // -- constrained random pass --
            for (int n = 0; n < num_per_op; n++) begin
                tr = new();
                // force this opcode, randomize operands
                if (!tr.randomize() with { operator == op_list[i]; })
                    $fatal(1, "randomize failed");
                gen2drv.put(tr);
            end
        end

        ->done;   // signal test we are finished producing
    endtask

endclass
